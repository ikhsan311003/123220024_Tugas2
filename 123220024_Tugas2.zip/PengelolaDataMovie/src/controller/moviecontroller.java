/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.util.List;
import DAOmovie.movieDAO;
import DAOImplement.movieimplement;
import model.*;
import view.MainView;
/**
 *
 * @author M S I
 */
public class moviecontroller {
    MainView frame;
    movieimplement implmovie;
    List<movie> mv;
    
    public moviecontroller(MainView frame){
        this.frame = frame;
        implmovie = new movieDAO();
        mv = implmovie.getAll();
    }
    
    public void isitabel(){
        mv = implmovie.getAll();
        modeltabelmovie mm = new modeltabelmovie(mv);
        frame.getTabelMovie().setModel(mm);
    }
    
    public void insert(String judul, double alur, double penokohan, double akting, double nilai){
    movie mv = new movie();
    mv.setJudul(judul);
    mv.setAlur(alur);
    mv.setPenokohan(penokohan);
    mv.setAkting(akting);
    mv.setNilai(nilai);
    implmovie.insert(mv);
    
    frame.getjTextjudul().setText("");
    frame.getjTextalur().setText("");
    frame.getjTextpenokohan().setText("");
    frame.getjTextakting().setText("");
    frame.getjTextnilai().setText("");
}

public void update(String judul, double alur, double penokohan, double akting, double nilai){
    movie mv = new movie();
    mv.setJudul(judul);
    mv.setAlur(alur);
    mv.setPenokohan(penokohan);
    mv.setAkting(akting);
    mv.setNilai(nilai);
    implmovie.update(mv);
    
    frame.getjTextjudul().setText("");
    frame.getjTextalur().setText("");
    frame.getjTextpenokohan().setText("");
    frame.getjTextakting().setText("");
    frame.getjTextnilai().setText("");
}

    
    public void delete(String judul) {
    implmovie.delete(judul);
    
    frame.getjTextjudul().setText("");
    frame.getjTextalur().setText("");
    frame.getjTextpenokohan().setText("");
    frame.getjTextakting().setText("");
    frame.getjTextnilai().setText("");
}

public void clear() {
    for (movie data : mv) {
        implmovie.delete(data.getJudul());
    }
}
}