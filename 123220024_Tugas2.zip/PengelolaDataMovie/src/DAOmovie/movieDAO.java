/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOmovie;
import java.sql.*;
import java.util.*;
import koneksi.connector;
import model.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import DAOImplement.movieimplement;
/**
 *
 * @author M S I
 */
public class movieDAO implements movieimplement{
    Connection connection;

    final String select = "SELECT * FROM movie";
    final String insert = "INSERT INTO movie (judul, alur, penokohan, akting, nilai) VALUES (?, ?, ?, ?, ?)";
    final String update = "update movie set alur=?, penokohan=?, akting=?, nilai=? where judul=?";
    final String delete = "delete from movie where judul=?";
    
    public movieDAO(){
        connection = connector.connection();
    }
    
    @Override
public void insert(movie p) {
    PreparedStatement statement = null;
    try {
        statement = connection.prepareStatement(insert);
        statement.setString(1, p.getJudul());
        statement.setDouble(2, p.getAlur());
        statement.setDouble(3, p.getPenokohan());
        statement.setDouble(4, p.getAkting());
        statement.setDouble(5, p.getNilai());
        statement.executeUpdate();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            statement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

@Override
public void update(movie p) {
    PreparedStatement statement = null;
    try {
        statement = connection.prepareStatement(update);
        statement.setDouble(1, p.getAlur());
        statement.setDouble(2, p.getPenokohan());
        statement.setDouble(3, p.getAkting());
        statement.setDouble(4, p.getNilai());
        statement.setString(5, p.getJudul());
        statement.executeUpdate();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            statement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

@Override
public void delete(String judul) {
    PreparedStatement statement = null;
    try {
        statement = connection.prepareStatement(delete);
        statement.setString(1, judul);
        statement.executeUpdate();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            statement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}


    @Override
    public List<movie> getAll() {
        List<movie> dp = null;
        try{
            dp = new ArrayList<movie>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                movie mv = new movie();
                mv.setJudul(rs.getString("judul"));
                mv.setAlur(rs.getDouble("alur"));
                mv.setPenokohan(rs.getDouble("penokohan"));
                mv.setAkting(rs.getDouble("akting"));
                mv.setNilai(rs.getDouble("nilai"));
                dp.add(mv);
            }
        }catch(SQLException ex){
            Logger.getLogger(movieDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return dp;
    }
    }